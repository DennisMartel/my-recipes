<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container py-8">
        <div class="grid lg:grid-cols-2 lg:gap-8 gap-4">
            <div>
                <div class="flexslider">
                    <ul class="slides">
                        <?php $__currentLoopData = $recipe->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-thumb="<?php echo e(Storage::url($image->url)); ?>">
                                <img src="<?php echo e(Storage::url($image->url)); ?>" />
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div>
                <div class="sticky top-24">
                    <div class="bg-white shadow-md rounded-xl px-6 py-6">
                        <h1 class="text-gray-600 text-2xl font-semibold mb-2"><?php echo e($recipe->name); ?></h1>
                        <div class="flex">
                            <p class="text-lg">
                                Categoria: 
                                <a class="underline"><?php echo e($recipe->subcategory->category->name); ?></a>
                            </p>
        
                            <p class="flex items-center mx-6">
                                <span>
                                    <?php echo e($recipe->rating); ?>

                                </span>
                                <i class="fas fa-star text-yellow-500"></i>
                            </p>
        
                            <p class="text-yellow-500 font-bold text-lg underline">
                                <?php echo e($recipe->reviews_count); ?> Reseñas
                            </p>
                        </div>
                        <p class="text-base text-gray-500 my-2 font-bold">Autor: <?php echo e($recipe->author->name); ?></p>
                        <p class="text-base font-semibold text-gray-500 mt-2"><?php echo e($recipe->description); ?></p>
    
                        <h1 class="text-red-600 font-semibold text-3xl mt-5">Ingredientes</h1>
                        <p class="text-base font-semibold text-gray-500 mt-2"><?php echo e($recipe->preparation); ?> <?php echo e($recipe->description); ?></p>
    
                        <h1 class="text-red-600 font-semibold text-3xl mt-5">Preparación</h1>
                        <p class="text-base font-semibold text-gray-500 mt-2"><?php echo e($recipe->preparation); ?> <?php echo e($recipe->description); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function() {
                $('.flexslider').flexslider({
                    animation: "slide",
                    controlNav: "thumbnails"
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\recetas\resources\views/recipe.blade.php ENDPATH**/ ?>