<div class="flex-1">
    <x-jet-input type="text" class="w-full focus:ring-0 focus:border-red-600 select-none" placeholder="Puedes buscar tú receta aquí"/>
</div>
