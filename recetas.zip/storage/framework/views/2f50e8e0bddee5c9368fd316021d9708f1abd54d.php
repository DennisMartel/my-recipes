<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <section class="relative mb-16">
        <div class="relative w-full h-96">
            <div class="absolute inset-0 w-full h-full bg-gray-900 bg-opacity-60"></div>
            <img class="object-cover object-bottom w-full h-full" src="<?php echo e(asset('img/banner.jpg')); ?>" alt="">
        </div>

        <div class="md:absolute sm:left-0 sm:top-0 w-full">

            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 sm:pt-6 md:pt-8 lg:pt-20">
                    <div class="bg-white shadow-xl sm:rounded-lg px-6 py-8 block md:max-w-sm md:py-2 lg:py-4">
                        <h1 class="font-bold text-3xl">Encuentra una receta para tu próxima comida</h1>

                        <p class="lg:text-lg">Divierteté con la explosión de sabor con los mejores ingredientes.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="container w-full pb-16">
        <h1 class="font-semibold text-2xl uppercase border-red-600 border-b-2 inline">últimas recetas</h1>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('recipes')->html();
} elseif ($_instance->childHasBeenRendered('1lR3QGj')) {
    $componentId = $_instance->getRenderedChildComponentId('1lR3QGj');
    $componentTag = $_instance->getRenderedChildComponentTagName('1lR3QGj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1lR3QGj');
} else {
    $response = \Livewire\Livewire::mount('recipes');
    $html = $response->html();
    $_instance->logRenderedChild('1lR3QGj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\recetas\resources\views/welcome.blade.php ENDPATH**/ ?>