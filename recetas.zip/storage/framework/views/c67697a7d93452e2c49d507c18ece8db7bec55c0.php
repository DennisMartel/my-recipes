<?php foreach($attributes->onlyProps(['category']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['category']); ?>
<?php foreach (array_filter((['category']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="px-4 py-4">
    <p class="font-extrabold text-lg text-center text-gray-700 mb-4">Subcategorias</p>

    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li>
            <a href="<?php echo e(route('subcategory', $subcategory)); ?>" class="flex py-1 px-2 text-gray-600 font-bold hover:text-red-600">
                <?php echo e($subcategory->name); ?>

            </a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center font-semibold text-base text-gray-500 pt-4">No hay subcategorias</p>
        <?php endif; ?>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\recetas\resources\views/components/navbar-subcategories.blade.php ENDPATH**/ ?>