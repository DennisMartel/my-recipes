<?php return array (
  'navigation' => 'App\\Http\\Livewire\\Navigation',
  'recipes' => 'App\\Http\\Livewire\\Recipes',
  'search' => 'App\\Http\\Livewire\\Search',
);